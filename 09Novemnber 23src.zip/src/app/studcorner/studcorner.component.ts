import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-studcorner',
  templateUrl: './studcorner.component.html',
  styleUrls: ['./studcorner.component.scss', '../equiry/equiry.component.scss', '../careers/careers.component.scss']
})
export class StudcornerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
