import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-equiry',
  templateUrl: './equiry.component.html',
  styleUrls: ['./equiry.component.scss']
})
export class EquiryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
